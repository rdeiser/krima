<?= $t('side-by-side', 
		array(
			'item' => $item,
			/*'title' => 'Item Information:',*/
			/*'leftTitle' => 'Scan Next Barcode',*/
			'rightTitle' => 'Item Information:',
		 )
	)
?>
