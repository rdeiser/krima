<?= $t('bib', array('bib' => $bib)) ?>
