# Groundwater - when your record needs watering on the ground

This grima has a function. It requires this from the API.
It displays this information on completion.

Here is a screenshot.

Here is why it is used, and how wide the audience for it is.

Here is a link to the [live version](Groundwater.php).
