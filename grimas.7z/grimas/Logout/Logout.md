# Logout - logout of grima

This grima logs you out of grima. You will have to 
[Login](../Login/Login.html) to use any other grima.

## API requirements
* (none)
