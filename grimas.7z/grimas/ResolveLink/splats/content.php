<div class='card mt-2 bib'>
  <div class='card-header'>
    <h3 class='card-title'>Link Resolved</h3>
  </div>
  <div class='card-body'>
	<p><a href="<?=$e($old_url)?>">Link</a> resolves to <a href="<?=$e($url)?>"><?=$e($url)?></a></p>
  </div>
</div>
