# DeleteBib - delete a bib record from Alma

This grima deletes a bib record from Alma.

## Input
* MMS ID of bib record to delete

## Output
This grima outputs a message indicating either:
* success - indicating the MMS ID of the record deleted
* error - including the error message from Alma

## API requirements
* Bibs - read/write
