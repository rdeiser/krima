# AdminRenameUser - rename a user 

Change a user's name in the grima login database
in the logged in administrator's institution.

## Input
* Username: username for the account you are changing
* Institution: user's institution
* New Username: username to change to

You can [list all users](../AdminListUsers/AdminListUsers.html)
as well.

## API requirements
* (none)
