# Login - login to grima

This grima checks your password, so you can use other grimas without further
authentication. We can't just allow every web-crawler to delete all our holdings.

This grima is called automatically if you try to access another grima while not
logged in. After a successful login, you will be redirected to the grima you
initially tried.

## Input
* login, password and instition as assigned by system administrator

## API requirements
* (none)
