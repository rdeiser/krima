<?= $t('head-metas') ?>
    <title><?=$e($title)?></title>
<?= $t('head-styles') ?>
<?= $t('head-scripts') ?>
