# AdminDeleteUser - remove an account

If you are logged in as an admin, you can delete accounts in your institution
so that they no longer have access to grima.

## Input
* Username: username for the account you are deleting

You can [list all remaining users](../AdminListUsers/AdminListUsers.html)
as well.

## API requirements
* (none)
