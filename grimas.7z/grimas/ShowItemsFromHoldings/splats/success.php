<?= $t('holding', array('holding' => $holding)) ?>
