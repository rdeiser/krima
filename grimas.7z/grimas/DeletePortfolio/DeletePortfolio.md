# DeletePortfolio - delete a portfolio from Alma

This grima deletes a portfolio from Alma.

## Input
* Portfolio ID of the portfolio to delete

## Output
This grima outputs a message indicating either:
* success - indicating the MMS ID of the record deleted
* error - including the error message from Alma

## API requirements
* Electronic - read/write
