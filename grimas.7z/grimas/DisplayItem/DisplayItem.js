document.addEventListener('DOMContentLoaded',()=>{
    inventory_date_elt.addEventListener('input',onUpdate);
});
