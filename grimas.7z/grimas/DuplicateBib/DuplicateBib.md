# DuplicateBib - create a copy of a bibliographic record in Alma

## Input
* MMS ID of bib record to duplicate

## Output
This grima outputs a message indicating either:
* success - including the MMS ID of the new copy of the bib record
* error - including the error message from Alma

## API requirements
* Bibs - read/write
