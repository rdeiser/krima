<?= $t('side-by-side', 
		array(
			'item' => $item,
			'title' => 'Add items in a series',
			'leftTitle' => 'New record',
			'rightTitle' => 'Item based on:',
		 )
	)
?>
