              <table class="table">
                <tr><th>Barcode:</th><td><?=$e($item['barcode'])?></td></tr>
                <tr><th>Enumeration A:</th><td><?=$e($item['enumeration_a'])?></td></tr>
                <tr><th>Enumeration B:</th><td><?=$e($item['enumeration_b'])?></td></tr>
                <tr><th>Chronology I:</th><td><?=$e($item['chronology_i'])?></td></tr>
                <tr><th>Chronology J:</th><td><?=$e($item['chronology_j'])?></td></tr>
                <tr><th>Description:</th><td><?=$e($item['description'])?></td></tr>
				<tr><th>Item Policy:</th><td><?=$e($item['item_policy'])?></td></tr>
                <tr><th>Title:</th><td><?=$e($item['title'])?></td></tr>
                <tr><th>Location:</th><td><?=$e($item['location'])?></td></tr>
                <tr><th>Call Number:</th><td><?=$e($item['call_number'])?></td></tr>
              </table>
