<ul>
<?php foreach($holdinglist as $holding): ?>
<li><h1 New Barcodes></h1>
<?=$item['barcode']?>
</li>
<?php endforeach ?>
</ul>