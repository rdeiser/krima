# AdminResetPassword - reset password

Reset a user's password in the grima login database
in the logged in administrator's institution.

## Input
* Username: username for the account you are reseting
* Password: new password for the account
* Institution: user's institution


You can [list all users](../AdminListUsers/AdminListUsers.html),
and reset each of their passwords, as well.

## API requirements
* (none)
